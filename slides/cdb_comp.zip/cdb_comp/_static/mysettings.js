// Turn autoSlide off
//Reveal.configure({ autoSlide: 0 });

logo = document.getElementById('logo');
logo.parentElement.parentElement.appendChild(logo);
